<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<title>Untitled Document</title>
<link href="portal.css" rel="stylesheet" type="text/css" />
</head>

<body>

<div id="Content">



  <!-- Conteudo do cabe�alho - titulo e mes-->
  <div id="header">
    <div id="titulo"><img src="images/titulo.png" /></div>
    <div id="mes"><img src="images/mes_fev.png" /></div>
  </div>
  
    
  <!-- MENU Navega��o -->
  <div id="navigation">
    <div id="nav_fst"><img src="images/personagens_bt.png" /></div>
    <div id="nav_spacer"><img src="images/spacer.png" width="25" height="10" /></div>
    <div id="nav_nxt"><img src="images/efemerides_bt.png" /></div>
    <div id="nav_spacer"><img src="images/spacer.png" width="25" height="10" /></div>
    <div id="nav_nxt"><img src="images/instituicoes_bt.png" /></div>
    <div id="nav_spacer"><img src="images/spacer.png" width="25" height="10" /></div>
    <div id="nav_nxt"><img src="images/modas_bt.png" /></div>
    <div id="nav_spacer"><img src="images/spacer.png" width="25" height="10" /></div>
    <div id="nav_mltm"><img src="images/multimedia_bt.png" width="144" height="30" /></div>
    <div id="nav_agd"><img src="images/agenda.png" width="154" height="30" /></div>
  </div>
  
  
  
  
  <!-- Conteudo de acontecimentos importantes -->
  <div id="news">

    <!-- Barra topo news -->
    <div id="top_bar_news_short">
      <div class="textbox">
        <div class="text_subtitulo_wh">Efem�rides</div>
        <div class="text_titulo_barra">Regic�dio de 1908</div>
      </div>
    </div>
    <!-- Coluna com texto -->
  <div id="columnText_media">
    	<div class="text_normal">
    	  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In metus elit, aliquet quis mollis ac, vulputate id quam. Sed lobortis luctus felis in sodales. Cras nec dolor a tortor lobortis accumsan porttitor id ante. Donec mollis semper leo, in placerat mauris commodo sit amet. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Morbi fermentum tincidunt eleifend. Quisque tristique luctus mi, vitae rhoncus ante porttitor et. Cras eu metus purus, semper imperdiet odio. Suspendisse in tellus at tortor rutrum cursus quis nec leo. Mauris semper, nulla adipiscing tincidunt interdum, metus massa cursus dolor, eget laoreet urna velit a orci. Duis accumsan, est ac fringilla ullamcorper, nibh nulla mollis lacus, a consequat leo elit eu elit. Phasellus eu magna massa. Duis vitae nunc et nisi venenatis pulvinar a ut odio. Nam sit amet ante lacus, in sodales mauris. Integer eget ipsum ut orci semper facilisis. Nunc euismod, enim vitae commodo sagittis, libero felis adipiscing sapien, at lobortis sapien arcu et massa. Cras bibendum lectus non tortor consequat fermentum. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Quisque tellus ante, viverra ut ultrices a, interdum eget turpis. Pellentesque porttitor auctor laoreet.<br />
roin non bibendum orci. Proin et interdum erat. Etiam dolor lorem, mattis id commodo laoreet, semper iaculis erat. In ullamcorper, urna ut cursus interdum, neque ligula molestie leo, nec laoreet mi lacus a felis. Pellentesque rhoncus adipiscing sapien, ut sodales ipsum semper id. Pellentesque pellentesque suscipit enim sit amet congue. Suspendisse imperdiet ante id felis semper fermentum in ut sapien. Curabitur imperdiet turpis sodales metus placerat ut ultrices sem consequat. Donec vel libero urna. Nunc vel sollicitudin augue. Mauris sem nunc, aliquet ut porttitor sed, blandit vel ante. Ut ac tellus non tortor varius faucibus. Nam vel ligula mauris, in iaculis tortor. Nulla vel volutpat mi. Maecenas ac leo diam, non scelerisque sapien. Praesent ullamcorper vestibulum fringilla. Etiam at facilisis odio. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. </p>
    	</div>
    </div>
    
    <!-- coluna foto -->
    <div id="column_media">
    	<img src="images/atentado_small.png" />
    </div>
    
    
  </div>
  <!-- Acaba a news -->
  
  <!-- R�gua horizontal -->
  <div id="horiz_ruler"><img src="images/hruler.png" width="882" height="16" /></div>
  
  <!-- Cronologia -->
  <!-- Carrossel em Flash -->
  <div id="flash_carrossel">  </div>
  <!-- R�gua horizontal -->
  <div id="horiz_ruler_2"><img src="images/hruler.png" width="882" height="16" /></div>
<!-- Fim News-->
</div>

<!-- Fim Content-->
</div>
<script type="text/javascript">
<!--
swfobject.registerObject("FlashID");
//-->
</script>
</body>
</html>