<?php
	$ligacao=mysql_connect("localhost","republic_leonel","Jvt)V=U7lQ5B") or die ("Problemas na ligação ao MySQL");
	//
?>
