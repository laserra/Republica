<?php
//database server
define('DB_SERVER', "localhost");

//database login name
define('DB_USER', "leonelse_leonel");
//database login password
define('DB_PASS', "Jvt)V=U7lQ5B");

//database name
define('DB_DATABASE', "leonelse_republica");

//smart to define your table names also
define('TABLE_ARTIGO', "artigo");
define('TABLE_FOTO', "foto");
define('TABLE_SECCAO',"seccao");
define('TABLE_BREVES',"breves");
define('TABLE_MULTIMEDIA',"multimedia");
define('TABLE_DESTAQUE',"destaque_multimedia");

?>